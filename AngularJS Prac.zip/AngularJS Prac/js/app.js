app = angular.module('myApp',['ui.router']);

app.config(function ($stateProvider) {
            $stateProvider.state('about',{
                url: '/about',
                templateUrl: 'about.html',
                controller: 'myCtrl'
            });

            $stateProvider.state('info',{
                url: '/info',
                templateUrl: 'info.html',
                controller: 'myCtrl'
            });
});

app.controller('myCtrl',function ($scope, $http, upperService) {
        $scope.info = 'Before you can begin to determine what the composition of a particular paragraph will be, you must first decide to your reader? The information in each paragraph must be related ';
        $scope.name = 'anurag';

        $scope.getData = function () {

        $http({
            method: 'GET',
            url: ' http://www.omdbapi.com/?i=tt3896198&apikey=305c0e1b'
        }).then(function sucess(response) {
            console.log('+++++++++++++++++++++');
            console.log(response.data);
            console.log('+++++++++++++++++++++');
            $scope.myData = response.data;
            $scope.pic = $scope.myData.Poster;
        },
        function error(response) {
            console.log('error in getting data');
        });
    };
    $scope.getData();

  //   $scope.customer = {
  //   name: 'AB',
  //   address: '1600 Amphitheatre'
  // };

  $scope.name = 'anurag behera';
  $scope.result = upperService.upperCase($scope.name);
  console.log('======================');
  console.log($scope.result);
  console.log('======================');

});

app.directive('myCustom', function () {
    return{
        templateUrl: 'custom.html'
    };
});

app.factory('upperService',function () {

    return{
        upperCase: function (input) {
        var output = input.toUpperCase();
        return output;
        }

    };

});
